from .matrix import Matrix

if __name__ == '__main__':
    matrix=Matrix()
    matrix.run()